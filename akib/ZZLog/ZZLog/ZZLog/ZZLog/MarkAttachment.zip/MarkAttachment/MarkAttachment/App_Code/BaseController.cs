﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for BaseController
/// </summary>
public class BaseController
{
    public BaseController()
    {
        //
        // TODO: Add constructor logic here
        //
    }
}

public class ManualTransactionOverrideAttachments
{
    public string transactionId;
    public string referenceFiles;
    public string isPaymentProcessed;
    public ManualTransactionOverrideAttachments()
    {

    }
}

public class SearchFormData
{
    public string txtProcess;
    public string Big_data;
    public string txtBegin;
    public string txtEnd;
    public string txtDATA1;
    public string txtDATA2;
    public string txtDATA3;
    public string txtDATA4;
    public string txtDATA5;
    public string txtDATA6;
    public string txtDATA7;
    public string txtDATA8;
    public string txtDATA9;
    public string txtDATA10;
    public string txtCALLERINFO;

    public SearchFormData()
    {

    }
}